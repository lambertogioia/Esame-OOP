package Dungeon_Adventure;

/**
 * Classe principale del gioco Dungeon Adventure.
 * Avvia il gioco e gestisce l'interazione con l'utente.
 */

public class Main {
    public static void main(String[] args) {
        new Game().start();
        
    }
}