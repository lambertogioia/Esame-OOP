package Dungeon_Adventure;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.logging.Logger; // "Ho integrato Logger per monitorare i momenti chiave del gioco, come l’inizio della partita, le ricompense selezionate e i nemici sconfitti."

import Dungeon_Adventure.Dungeon_Adventure.backpack.*;
import Dungeon_Adventure.Dungeon_Adventure.backpack.Package;
import Dungeon_Adventure.Dungeon_Adventure.battle.*;
import Dungeon_Adventure.Dungeon_Adventure.characters.*;
import Dungeon_Adventure.Dungeon_Adventure.characters.hero_factory.HeroFactory;
import Dungeon_Adventure.Dungeon_Adventure.characters.hero_factory.MageFactory;
import Dungeon_Adventure.Dungeon_Adventure.characters.hero_factory.RogueFactory;
import Dungeon_Adventure.Dungeon_Adventure.characters.hero_factory.WarriorFactory;

import Dungeon_Adventure.Dungeon_Adventure.game_logger.GameLogger; // Logger personalizzato

import java.util.Iterator; //  AGGIUNTO PER ITERATOR

/**
 * Classe principale del gioco Dungeon Adventure.
 * Gestisce l'inizio del gioco, la selezione dell'avventuriero, l'esplorazione delle stanze e le battaglie con i nemici.
 * Utilizza il pattern Template Method per le battaglie e il pattern Factory per la creazione degli eroi.
 */

public class Game {
    private Player player;
    private ArrayList<Enemy> enemies;
    private Scanner scanner;
    private static final Logger logger = GameLogger.getLogger("Main");
    
    /**
     * Inizializza il gioco, seleziona l'avventuriero e inizia l'esplorazione del dungeon.
     * Crea le stanze e gestisce le battaglie con i nemici.
     */

    public void start() {
        scanner = new Scanner(System.in);

        System.out.println("=== DUNGEON ADVENTURE ===");
        logger.info("La partita è iniziata.");
        selectAdventurer();

        // Inizializza i nemici per ogni stanza
        initializeEnemies();

        // Esplora le 3 stanze del dungeon
        for (int roomNum = 1; roomNum <= 3; roomNum++) {
            try {
                createRooms(roomNum);
                exploreRoom(roomNum);
            } catch (Exception e) { // gestione game over
                System.exit(0);
            }
        }

        System.out.println("\n=== HAI COMPLETATO IL DUNGEON! ===");
        System.out.println("Ricompense ottenute:");

        //  NUOVO: STAMPA CON ITERATOR
        Iterator<BackpackItem> iterator = new BackpackIterator(player.getBackpack().getItems());
        while (iterator.hasNext()) {
            iterator.next().display("  ");
        }

        scanner.close();
    }


    /**
     * Seleziona l'avventuriero da giocare.
     * Mostra le opzioni disponibili e crea un eroe in base alla scelta dell'utente.
     */
    private void selectAdventurer() {
        // magari rivedere l'implementazione usando un array per gli eroi
        System.out.println("\nScegli il tuo avventuriero:");
        System.out.println("1. Elder Knight(Guerriero) - " + new WarriorFactory().getDescription());
        System.out.println("2. Weather Wizard(Mago) - " + new MageFactory().getDescription());
        System.out.println("3. Sneaky Thief(Arciere) - " + new RogueFactory().getDescription());

        int choice = 0;
        while (choice < 1 || choice > 3) {
            System.out.println("Scelta (1-3): ");
            try {
                choice = Integer.parseInt(scanner.nextLine().trim()); //  AGGIUNTO X EXCEPTION SHIELDING
            } catch (NumberFormatException e) {
                System.out.println(" Inserisci un numero valido!");
                choice = 0;
            }
        }

        HeroFactory factory = switch (choice) {
            case 1 -> new WarriorFactory();
            case 2 -> new MageFactory();
            case 3 -> new RogueFactory();
            default -> {

                throw new IllegalArgumentException(" Scelta non valida, riprova.");
            }
        };

        player = factory.createHero();

        System.out.println("Hai scelto: " + player.getName());

    }

    /**
     * Inizializza i nemici per le stanze del dungeon.
     * Utilizza una factory centralizzata per creare i nemici.
     */
    private void initializeEnemies() {
        enemies = Enemy.createDefaultEnemies(); // Usa factory centralizzata
    }

    /**
     * Crea una stanza del dungeon e simula il caricamento.
     * Mostra un messaggio di caricamento con puntini per indicare il progresso.
     *
     * @param roomNum Numero della stanza da creare (1, 2 o 3).
     */
    private void createRooms(int roomNum) {
        Thread roomLoader = new Thread(() -> {
            try {
                System.out.print("Caricamento della stanza " + roomNum + " in corso");

                for (int i = 0; i < 3; i++) {
                    Thread.sleep(1000); // Aspetta 1 secondo
                    System.out.print("."); // Stampa puntino sulla stessa riga
                }

                System.out.println(); // Va a capo dopo i 3 puntini

                // Simulazione della generazione della stanza
                String simulatedRoom = "Stanza " + roomNum;
                logger.info("Stanza " + roomNum + " caricata.\n" + simulatedRoom);

            } catch (InterruptedException e) {
                System.err.println(" Errore durante il caricamento della stanza " + roomNum + ": " + e.getMessage());
            }
        });

        roomLoader.start();

        try {
            roomLoader.join(); // Aspetta che la stanza venga simulata prima di continuare
        } catch (InterruptedException e) {
            logger.warning("Il thread di caricamento della stanza è stato interrotto.");
        }
    }

    /**
     * Esplora una stanza specifica del dungeon.
     * Gestisce il combattimento con il nemico presente nella stanza.
     * Se il giocatore vince, mostra le ricompense disponibili.
     *
     * @param roomNum Numero della stanza da esplorare (1, 2 o 3).
     */
    private void exploreRoom(int roomNum) {

        // Combattimento
        Enemy currentEnemy = enemies.get(roomNum - 1);
        System.out.println("\nUn " + currentEnemy.getName() + " ti attacca!");

        // Combattimento tramite Template Method
        BattleTemplate battle = new StandardBattle(player, currentEnemy, scanner);
        boolean success = battle.executeBattle();

        if (success) {
            logger.info("Nemico sconfitto: " + currentEnemy.getName());
            showRewardSelection();
        } else {
            System.out.println("Game over...");
            throw new RuntimeException("Il giocatore è stato sconfitto!"); // NUOVO: lancia eccezione per terminare il gioco
        }
    }
 
    /**
     * Mostra le ricompense disponibili dopo aver sconfitto un nemico.
     * Permette al giocatore di scegliere una ricompensa da aggiungere al suo zaino.
     */
    private void showRewardSelection() {
        ArrayList<BackpackItem> rewards = new ArrayList<>();

        Package utilityPack = new Package("Sacchetto:");
        utilityPack.add(new Item("50x Oro"));
        utilityPack.add(new Item("250x Argento"));

        rewards.add(new Item("100x Oro"));
        rewards.add(new Item("500x Argento"));
        rewards.add(utilityPack);

        System.out.println("\nScegli una ricompensa:");
        for (int i = 0; i < rewards.size(); i++) {
            System.out.print((i + 1) + ". ");
            rewards.get(i).display(""); // VISUALIZZAZIONE con display() del Composite Pattern
        }

        int choice = 0;
        while (choice < 1 || choice > rewards.size()) {
            System.out.print("Scelta (1-" + rewards.size() + "): ");
            try {
                choice = Integer.parseInt(scanner.nextLine().trim()); // AGGIUNTO X EXCEPTION SHIELDING
            } catch (NumberFormatException e) {
                System.out.println("Inserisci un numero valido!");
                choice = 0;
            }
        }

        BackpackItem selected = rewards.get(choice - 1); // NUOVO tipo
        player.getBackpack().addItem(selected); // oggetto aggiunto allo zaino
        player.saveBackpackToFile("backpack.txt"); // Salvataggio I/O
        logger.info("Ricompensa scelta: " + selected.getName());
        System.out.println("Hai ottenuto: " + selected.getName()); // FEEDBACK

    }

}
