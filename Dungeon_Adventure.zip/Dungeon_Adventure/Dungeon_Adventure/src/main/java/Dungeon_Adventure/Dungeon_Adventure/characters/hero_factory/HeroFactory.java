package Dungeon_Adventure.Dungeon_Adventure.characters.hero_factory;


import Dungeon_Adventure.Dungeon_Adventure.characters.Player;

/**
 * Interfaccia per la creazione di eroi.
 * Le implementazioni definiranno il tipo di eroe e le sue caratteristiche.
 */

public interface HeroFactory {
    Player createHero();
    String getDescription();
}
