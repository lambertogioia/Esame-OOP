package Dungeon_Adventure.Dungeon_Adventure.characters;

import Dungeon_Adventure.Dungeon_Adventure.backpack.Backpack;
import Dungeon_Adventure.Dungeon_Adventure.backpack.BackpackItem;

/**
 * Classe base per i personaggi del gioco.
 * Rappresenta un personaggio con attributi di salute, attacco, difesa e nome.
 * Ogni personaggio ha uno zaino per gestire gli oggetti.
 */

public class GameCharacter {

    protected int health;
    protected int attack;
    protected int defense;
    protected String name;
    protected Backpack<BackpackItem> backpack = new Backpack<>(); // AGGIUNTO: ora ogni GameCharacter ha uno zaino

    public GameCharacter(String name, int attack, int health, int defense) { // Perchè non sto dichiarando gli array nel campo delle variabili del costruttore?
        this.name = name;
        this.attack = attack;
        this.health = health;
        this.defense = defense;
    }
    
    // getter 
    public String getName() { return name; }
    public int getHealth() { return health; }
    public boolean isAlive() { return health > 0;}
    

   public void takeDamage(int damage) {
    int actualDamage = Math.max(1, damage - defense);  // perchè non devo dichiarare actuale damege all'inizio? perchè è il risultato di variabili note? NB
    health -= actualDamage;
    System.out.println(name + " subisce " + actualDamage + " danni! ");

   }

   public Backpack<BackpackItem> getBackpack() {
    return backpack;
}

    


}
