package Dungeon_Adventure.Dungeon_Adventure.Moves;

/**
 * Classe che rappresenta un'azione o un attacco che un personaggio può eseguire.
 * Ogni mossa ha un nome, una potenza e una precisione.
 */

public class Move {
    private String name;
    private int power;
    private double accuracy;

    public Move(String name, int power, double accuracy){
        this.name = name;
        this.power = power;
        this.accuracy = accuracy;
    }

    // Getters
    public String getName() { return name; }
    public int getPower() { return power; }
    public double getAccuracy() { return accuracy; }

    @Override
    public String toString() {
        return name + " (Potenza: " + power + ", Precisione: " + (int)(accuracy*100) + "%)";
    }
    
}
