package Dungeon_Adventure.Dungeon_Adventure.backpack;

import java.util.ArrayList;
import java.util.List;

/**
 * Classe che rappresenta un pacchetto di oggetti nello zaino del giocatore.
 * Implementa l'interfaccia BackpackItem e consente di aggiungere, rimuovere e visualizzare oggetti.
 */

public class Package implements BackpackItem {
    private final String name;
    private final List<BackpackItem> items = new ArrayList<>();

    public Package(String name) {
        this.name = name;
    }

    public void add(BackpackItem item) {
        items.add(item);
    }

    public void remove(BackpackItem item) {
        items.remove(item);
    }


    @Override
    public String getName() {
        return name;
    }


    @Override
    public void display(String indent) {
        System.out.println(indent + "+ " + name);
        for (BackpackItem item : items) {
            item.display(indent + "  ");
        }
    }
}