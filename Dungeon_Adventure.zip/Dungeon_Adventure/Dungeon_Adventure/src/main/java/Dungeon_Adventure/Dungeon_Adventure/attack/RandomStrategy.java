package Dungeon_Adventure.Dungeon_Adventure.attack;

import java.util.Random;

import Dungeon_Adventure.Dungeon_Adventure.characters.Enemy;
import Dungeon_Adventure.Dungeon_Adventure.characters.Player;

/**
 * Implementazione della strategia di attacco casuale.
 * Questa strategia infligge un danno casuale compreso tra la metà e il doppio dell'attacco base del nemico.
 */

public class RandomStrategy implements AttackStrategy {
    private final Random random = new Random();

    @Override
    public void attack(Player player, Enemy enemy) {
        int base = enemy.getAttack();
        int damage = base / 2 + random.nextInt(base);
        player.takeDamage(damage);
        System.out.println(enemy.getName() + " attacca in modo imprevedibile infliggendo " + damage + " danni!");
    }
}

