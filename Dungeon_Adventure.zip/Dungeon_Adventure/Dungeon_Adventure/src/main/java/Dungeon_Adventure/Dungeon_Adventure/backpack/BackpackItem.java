package Dungeon_Adventure.Dungeon_Adventure.backpack;

/**
 * Interfaccia che rappresenta un oggetto nello zaino del giocatore.
 * Ogni oggetto deve implementare il metodo display per mostrare le informazioni
 * e fornire un metodo getName per ottenere il nome dell'oggetto.
 */

public interface BackpackItem {
    void display(String indent);
    String getName(); 

}
