package Dungeon_Adventure.Dungeon_Adventure.attack;

import Dungeon_Adventure.Dungeon_Adventure.characters.Player;
import Dungeon_Adventure.Dungeon_Adventure.characters.Enemy;

/**
 * Implementazione della strategia di attacco aggressiva.
 * Questa strategia aumenta il danno inflitto dal nemico del 20%.
 */
public class AggressiveStrategy implements AttackStrategy {
    @Override
    public void attack(Player player, Enemy enemy) {
        int damage = (int)(enemy.getAttack() * 1.2);
        player.takeDamage(damage);
        System.out.println(enemy.getName() + " attacca brutalmente infliggendo " + damage + " danni!");
    }
}
