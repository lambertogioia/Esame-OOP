package Dungeon_Adventure.Dungeon_Adventure.game_logger;

import java.io.IOException;
import java.util.logging.*;
/**
 * Singleton per la gestione del logger del gioco.
 * Configura i logger per file e console con formattazione personalizzata.
 */

public class GameLogger {
    private static final Logger logger = Logger.getLogger("DungeonAdventure");

    static {
        logger.setUseParentHandlers(false); // Evita output doppio dal root logger
        logger.setLevel(Level.ALL);

        try {
            // File log
            FileHandler fileHandler = new FileHandler("dungeon_log.txt", true);
            fileHandler.setLevel(Level.ALL);
            fileHandler.setFormatter(new CustomFormatter()); // formatter personalizzato

            // Console log
            ConsoleHandler consoleHandler = new ConsoleHandler();
            consoleHandler.setLevel(Level.ALL);
            consoleHandler.setFormatter(new CustomFormatter()); // formatter personalizzato

            // Aggiunta handler
            logger.addHandler(fileHandler);
            logger.addHandler(consoleHandler);

        } catch (IOException e) {
            System.err.println("Errore nella configurazione del logger: " + e.getMessage());
        }
    }

    public static Logger getLogger(String moduleName) {
        return logger;
    }
}
