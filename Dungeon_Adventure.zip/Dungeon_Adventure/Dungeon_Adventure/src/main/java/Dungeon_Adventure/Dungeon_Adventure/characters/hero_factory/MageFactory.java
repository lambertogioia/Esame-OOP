package Dungeon_Adventure.Dungeon_Adventure.characters.hero_factory;

import Dungeon_Adventure.Dungeon_Adventure.Moves.*;
import Dungeon_Adventure.Dungeon_Adventure.characters.Player;

/**
 * Classe che implementa la creazione di un eroe di tipo Mago.
 * Il Mago ha attacchi speciali, una vita bassa e una difesa molto bassa.
 */

public class MageFactory implements HeroFactory {
    @Override
    public Player createHero() {
        Player mage = new Player("Weather Wizard", 80, 30, 10);
        mage.addMove(new Move("Palla di fuoco", 35, 0.90));
        mage.addMove(new Move("Fulmine", 45, 0.75));
        return mage;
    }

    @Override
    public String getDescription() {
        return "Attacchi speciali (30), vita bassa (80), difesa molto bassa (10)";
    }
}
