package Dungeon_Adventure.Dungeon_Adventure.backpack;

import java.util.ArrayList;
import java.util.List;

/**
 * Classe che rappresenta uno zaino generico per contenere oggetti di tipo BackpackItem.
 * Utilizza i generics per garantire che solo oggetti di tipo T possano essere aggiunti.
 *
 * @param <T> Il tipo di oggetti che lo zaino può contenere, deve estendere BackpackItem.
 */
public class Backpack <T extends BackpackItem> {
    // private final List<BackpackItem> items = new ArrayList<>(); prima di generics
    private final List<T> items = new ArrayList<>(); //  AGGIUNTO PER GENERICS

     public void addItem(T item) {
        items.add(item);
    }

    public void removeItem(T item) {
        items.remove(item);
    }

    public List<T> getItems() {
        return items;
    }
   
    public <S extends T> List<S> getItemsOfType(Class<S> type) {
        List<S> result = new ArrayList<>();
        for (T item : items) {
            if (type.isInstance(item)) {
                result.add(type.cast(item));
            }
        }
        return result;
    }

    public void displayContents() {
        if (items.isEmpty()) {
            System.out.println("  (vuoto)");
        } else {
            for (T item : items) {
                item.display("  ");
            }
        }
    }

    public boolean isEmpty() {
        return items.isEmpty();
    }
}