package Dungeon_Adventure.Dungeon_Adventure.battle;

import java.util.Scanner;
import java.util.logging.Logger;

import Dungeon_Adventure.Dungeon_Adventure.Moves.Move;
import Dungeon_Adventure.Dungeon_Adventure.characters.Enemy;
import Dungeon_Adventure.Dungeon_Adventure.characters.Player;
import Dungeon_Adventure.Dungeon_Adventure.game_logger.GameLogger;

/**
 * Classe che gestisce una battaglia standard tra un giocatore e un nemico.
 * Estende la classe BattleTemplate per implementare i metodi specifici della battaglia.
 */
public class StandardBattle extends BattleTemplate {
    private final Scanner scanner;
    private static final Logger logger = GameLogger.getLogger("StandardBattle");

    public StandardBattle(Player player, Enemy enemy, Scanner scanner) {
        super(player, enemy);
        this.scanner = scanner;
    }

    /**
     * Esegue la battaglia tra il giocatore e il nemico.
     * Mostra lo stato iniziale, gestisce i turni del giocatore e del nemico,
     * e conclude la battaglia mostrando il risultato.
     *
     * @return true se il giocatore vince, false altrimenti
     */
    @Override
    protected void playerTurn() {
        logger.info("Inizia il turno del giocatore.");
        System.out.println("\nScegli la tua mossa:");
        player.showMoves();
        int choice = 0;
        while (choice < 1 || choice > player.getMovesCount()) {
        System.out.print("Scelta (1-" + player.getMovesCount() + "): ");
        try {
            choice = Integer.parseInt(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            System.out.println("Inserisci un numero valido!");
            choice = 0;
        }
    }
        Move selectedMove = player.getMove(choice - 1);
        player.attack(enemy, selectedMove);
    }

    @Override
    
    protected void enemyTurn() {
        logger.info("Inizia il turno del nemico.");
        enemy.attack(player);
    }

    @Override
    protected void showStatus() {
        System.out.println("\n" + player.getName() + ": HP " + player.getHealth());
        System.out.println(enemy.getName() + ": HP " + enemy.getHealth());
    }


    @Override
    protected boolean conclude() {
        if (player.isAlive()) {
            System.out.println("\nHai sconfitto il " + enemy.getName() + "!");
            return true;
        } else {
            System.out.println("\nSei stato sconfitto...!");
            return false;
        }
    }
}
