package Dungeon_Adventure.Dungeon_Adventure.characters;

import java.util.ArrayList;


import Dungeon_Adventure.Dungeon_Adventure.attack.*;
import Dungeon_Adventure.Dungeon_Adventure.characters.enemy_builder.*;


/**
 * Classe che rappresenta un nemico nel gioco.
 * Estende la classe GameCharacter e implementa il pattern Strategy per le strategie di attacco.
 * Implementa anche il pattern Builder per la creazione di nemici con attributi personalizzati.
 */

public class Enemy extends GameCharacter {

    private AttackStrategy strategy = new AggressiveStrategy(); // ✅ STRATEGY PATTERN

    public Enemy(String name, int health, int attack, int defense) {
        super(name, attack, health, defense);
    }

    
    public void setStrategy(AttackStrategy strategy) {
        this.strategy = strategy;
    }

    public void attack(Player player) {
        strategy.attack(player, this); //  STRATEGIA DI ATTACCO
    }

    public int getAttack() { //  AGGIUNTO PER STRATEGY
        return this.attack;
    }

    public boolean isDefeated() {
        return !isAlive();
    }

    //  METODO STATICO: crea nemici con strategia associata
    public static ArrayList<Enemy> createDefaultEnemies() {
        ArrayList<Enemy> enemies = new ArrayList<>();

        Enemy goblin = new EnemyBuilder()
            .setName("Goblin")
            .setHealth(50)
            .setAttack(15)
            .setDefense(5)
            .build();
        goblin.setStrategy(new RandomStrategy());

        Enemy orc = new EnemyBuilder()
            .setName("Orco")
            .setHealth(80)
            .setAttack(20)
            .setDefense(10)
            .build();
        orc.setStrategy(new AggressiveStrategy());

        Enemy dragon = new EnemyBuilder()
            .setName("Drago")
            .setHealth(120)
            .setAttack(30)
            .setDefense(15)
            .build();
        dragon.setStrategy(new RandomStrategy());

        enemies.add(goblin);
        enemies.add(orc);
        enemies.add(dragon);

        return enemies;
    }
} 
