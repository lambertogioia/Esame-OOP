package Dungeon_Adventure.Dungeon_Adventure.battle;


import Dungeon_Adventure.Dungeon_Adventure.characters.Player;
import Dungeon_Adventure.Dungeon_Adventure.characters.Enemy;

/**
 * Classe astratta che definisce il template per le battaglie.
 * Le sottoclassi devono implementare i metodi specifici per il turno del giocatore,
 * il turno del nemico, la visualizzazione dello stato e la conclusione della battaglia.
 */
public abstract class BattleTemplate {
    protected Player player;
    protected Enemy enemy;

    public BattleTemplate(Player player, Enemy enemy) {
        this.player = player;
        this.enemy = enemy;
    }

    public final boolean executeBattle() {
        while (player.isAlive() && enemy.isAlive()) {
            showStatus();
            playerTurn();
            if (enemy.isAlive()) enemyTurn();
        }
        return conclude();
    }

    protected abstract void playerTurn();
    protected abstract void enemyTurn();
    protected abstract void showStatus();
    protected abstract boolean conclude();
} 
