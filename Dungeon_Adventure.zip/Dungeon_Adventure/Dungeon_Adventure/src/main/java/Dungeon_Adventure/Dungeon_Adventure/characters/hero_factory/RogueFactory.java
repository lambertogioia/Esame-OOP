package Dungeon_Adventure.Dungeon_Adventure.characters.hero_factory;

import Dungeon_Adventure.Dungeon_Adventure.Moves.*;
import Dungeon_Adventure.Dungeon_Adventure.characters.Player;

/**
 * Classe che implementa la creazione di un eroe di tipo Ladro.
 * Il Ladro ha attacchi a distanza, è agile e ha una vita media.
 */

public class RogueFactory implements HeroFactory {
    @Override
    public Player createHero() {
        Player rogue = new Player("Sneaky Thief", 100, 20, 20);
        rogue.addMove(new Move("Pugnalata", 25, 0.99));
        rogue.addMove(new Move("Scaglia una freccia", 50, 0.60));
        return rogue;
    }

    @Override
    public String getDescription() {
        return "Attacco a distanza (22), agile (12), vita media (90)";
    }
}