package Dungeon_Adventure.Dungeon_Adventure.characters;

import java.util.ArrayList;
import java.io.*;

import Dungeon_Adventure.Dungeon_Adventure.Moves.*;
import Dungeon_Adventure.Dungeon_Adventure.backpack.Backpack;
import Dungeon_Adventure.Dungeon_Adventure.backpack.BackpackItem;
import Dungeon_Adventure.Dungeon_Adventure.backpack.Item;


/**
 * Classe che rappresenta un giocatore nel gioco.
 * Estende la classe GameCharacter e gestisce le mosse del giocatore e lo zaino.
 */

public class Player extends GameCharacter{
    private ArrayList<Move> moves;
    private Backpack<BackpackItem> backpack = new Backpack<>(); // CAMBIATO: usato oggetto Backpack invece di ArrayList<String>

    public Player(String name, int attack, int health, int defense) { // Perchè non sto dichiarando gli array nel campo delle variabili del costruttore?
        super(name, attack, health, defense); // gli attributi ereditati dalla superclasse vanno dichiarati in un colpo solo.
        this.moves = new ArrayList<>();
    }
    
    // getter 
    public int getMovesCount() { return moves.size(); }
    public Move getMove(int index) { return moves.get(index);}

   public void attack (Enemy enemy, Move move) {
    if (Math.random() < move.getAccuracy()) {
        int damage = (int)(move.getPower() * (attack / 10.0)); //Possiamo semplificare il calcolo dei danni escludendo completamente la variabile attacco dall'equazione e costruendo tutto sulla base della potenza delle abilità
        enemy.takeDamage(damage);         //NB
        System.out.println(name + " usa " + move.getName() + " e infligge " + damage + " danni! ");
    }else{
        System.out.println(name + " usa " + move.getName() + " ma fallisce! ");
    }

   }

   public void addMove(Move move) {
    moves.add(move);
   }

   public void showMoves() {
    for (int i = 0; i<moves.size(); i++) {
        System.out.println((i+1) + ". " + moves.get(i));
    }
   }

   public void addToBackpack(String itemName) {
        backpack.addItem(new Item(itemName)); // CAMBIATO: crea e aggiunge oggetto Item al Backpack
    }

    public void showBackpack() {
        backpack.displayContents(); // CAMBIATO: usa metodo del Composite Pattern
    }

    public void saveBackpackToFile(String filename) {
    try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename))) {
        for (BackpackItem item : backpack.getItems()) {
            writer.write(item.getName());
            writer.newLine();
        }
        System.out.println("Zaino salvato su file: " + filename);
    } catch (IOException e) {
        System.out.println("Errore durante il salvataggio: " + e.getMessage());
    }
    
}
    public void loadBackpackFromFile(String filename) {
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = reader.readLine()) != null) {
                backpack.addItem(new Item(line)); // CAMBIATO: crea e aggiunge oggetto Item al Backpack
            }
            System.out.println("Zaino caricato da file: " + filename);
        } catch (IOException e) {
            System.out.println("Errore durante il caricamento: " + e.getMessage());
        }
    }

}
    


   
   
   


    

