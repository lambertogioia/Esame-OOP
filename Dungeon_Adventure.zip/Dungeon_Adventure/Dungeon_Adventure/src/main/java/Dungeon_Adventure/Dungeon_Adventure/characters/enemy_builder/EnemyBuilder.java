package Dungeon_Adventure.Dungeon_Adventure.characters.enemy_builder;

import Dungeon_Adventure.Dungeon_Adventure.characters.Enemy;

/**
 * Classe per costruire oggetti Enemy utilizzando il pattern Builder.
 * Permette di creare nemici con attributi personalizzati come nome, salute, attacco e difesa.
 */
public class EnemyBuilder {
    private String name;
    private int health;
    private int attack;
    private int defense;

    public EnemyBuilder setName(String name) {
        this.name = name;
        return this;
    }

    public EnemyBuilder setHealth(int health) {
        this.health = health;
        return this;
    }

    public EnemyBuilder setAttack(int attack) {
        this.attack = attack;
        return this;
    }

    public EnemyBuilder setDefense(int defense) {
        this.defense = defense;
        return this;
    }

    public Enemy build() {
        return new Enemy(name, health, attack, defense);
    }
}
