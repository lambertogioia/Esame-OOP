package Dungeon_Adventure.Dungeon_Adventure.attack;


import Dungeon_Adventure.Dungeon_Adventure.characters.Player;
import Dungeon_Adventure.Dungeon_Adventure.characters.Enemy;
/**
 * Interfaccia per le strategie di attacco.
 * Le implementazioni definiranno il comportamento di attacco specifico.
 */
public interface AttackStrategy {
    void attack(Player player, Enemy enemy);
}

