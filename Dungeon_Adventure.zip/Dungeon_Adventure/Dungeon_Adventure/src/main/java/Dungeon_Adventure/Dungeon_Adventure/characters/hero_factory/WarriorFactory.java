package Dungeon_Adventure.Dungeon_Adventure.characters.hero_factory;

import Dungeon_Adventure.Dungeon_Adventure.Moves.*;
import Dungeon_Adventure.Dungeon_Adventure.characters.Player;


/**
 * Classe che implementa la creazione di un eroe di tipo Guerriero.
 * Il Guerriero ha attacchi ravvicinati, una vita alta e una difesa bassa.
 */

public class WarriorFactory implements HeroFactory {
    @Override
    public Player createHero() {
        Player warrior = new Player("Elder Knight", 120, 25, 15);
        warrior.addMove(new Move("Spadata", 30, 0.95));
        warrior.addMove(new Move("Fendente", 40, 0.80));
        return warrior;
    }

    @Override
    public String getDescription() {
        return "Alto attacco (25), bassa difesa (15), vita alta (120)";
    }
}
