package Dungeon_Adventure.Dungeon_Adventure.backpack;

/**
 * Classe che rappresenta un oggetto nello zaino del giocatore.
 * Implementa l'interfaccia BackpackItem e fornisce un metodo per visualizzare le informazioni dell'oggetto.
 */

public class Item implements BackpackItem {
    private final String name;

    public Item(String name) {
        this.name = name;
    }


    @Override
    public void display(String indent) {
        System.out.println(indent + "- " + name);
    }

    @Override
    public String getName() {
        return name;
    }

}

