package Dungeon_Adventure.Dungeon_Adventure.backpack;

import java.util.Iterator;
import java.util.List;


/**
 * Classe che implementa l'interfaccia Iterator per iterare sugli oggetti dello zaino.
 * Utilizza un indice per tenere traccia della posizione corrente nell'elenco degli oggetti.
 */
public class BackpackIterator implements Iterator<BackpackItem> {
    private final List<BackpackItem> items;
    private int index = 0;

    public BackpackIterator(List<BackpackItem> items) {
        this.items = items;
    }

    @Override
    public boolean hasNext() {
        return index < items.size();
    }

    @Override
    public BackpackItem next() {
        return items.get(index++);
    }
} 
