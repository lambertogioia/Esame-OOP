import org.junit.jupiter.api.Test;

// Update the package names below to match your actual source structure.
// For example, if your package is 'dungeon_adventure.characters', use:
import Dungeon_Adventure.Dungeon_Adventure.characters.Enemy;
import Dungeon_Adventure.Dungeon_Adventure.characters.enemy_builder.*;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Classe di test per la classe EnemyBuilder.
 * Verifica la corretta costruzione di oggetti Enemy utilizzando il pattern Builder.
 * Utilizza JUnit 5 per i test unitari.
 */
// Testo una classe costruttore

public class EnemyBuilderTest {

    // Test per verificare la costruzione di un nemico base

    @Test
    public void testBuildBasicEnemy() {
        Enemy goblin = new EnemyBuilder()
            .setName("Goblin")
            .setHealth(50)
            .setAttack(10)
            .setDefense(5)
            .build();

        assertEquals("Goblin", goblin.getName());
        assertEquals(50, goblin.getHealth());
        assertTrue(goblin.isAlive());
    }

    // Test per verificare se un nemico con attacco e difesa zero è ancora vivo

    @Test
    public void testNegativeHealth() {
        Enemy phantom = new EnemyBuilder()
            .setName("Phantom")
            .setHealth(-10)
            .setAttack(0)
            .setDefense(0)
            .build();

        assertEquals("Phantom", phantom.getName());
        assertEquals(-10, phantom.getHealth());
        assertFalse(phantom.isAlive());
    }
}