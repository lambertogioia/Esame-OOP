import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;



import Dungeon_Adventure.Dungeon_Adventure.Moves.Move;
import Dungeon_Adventure.Dungeon_Adventure.characters.*;

import static org.junit.jupiter.api.Assertions.*;



// Testo una classe logica principale
/**
 * Classe di test per la classe Player.
 * Verifica il corretto funzionamento delle funzionalità del giocatore,
 * come l'aggiunta di mosse, l'attacco a nemici e la gestione dello zaino.
 * Utilizza JUnit 5 per i test unitari.
 */
public class PlayerTest {

    private Player player;
    private Enemy dummyEnemy;

    @BeforeEach
    public void setup() {
        player = new Player("TestHero", 100, 10, 5);
        dummyEnemy = new Enemy("Dummy", 50, 5, 0);
    }

    // Test per verificare se il metodo non crasha e accetta stringhe

    @Test
    public void testAddToBackpack() {
        player.addToBackpack("Pozione");
        // display non ritorna valori, ma possiamo verificare che non dia errore
        assertDoesNotThrow(() -> player.showBackpack());
    }

    //Test per verificare se aggiunta e recupero di mosse funzionano correttamente

    @Test
    public void testAddMoveAndRetrieve() {
        Move m = new Move("Pugno", 20, 1.0);
        player.addMove(m);

        assertEquals(1, player.getMovesCount());
        assertEquals("Pugno", player.getMove(0).getName());
    }

    // Test per verificare se il giocatore può attaccare un nemico e infliggere danni

    @Test
    public void testAttackEnemy() {
        Move attacco = new Move("Fendente", 30, 1.0); // 100% hit
        player.addMove(attacco);

        int enemyHPBefore = dummyEnemy.getHealth();
        player.attack(dummyEnemy, attacco);

        assertTrue(dummyEnemy.getHealth() < enemyHPBefore, "Il nemico dovrebbe aver subito danno");
    }
}
