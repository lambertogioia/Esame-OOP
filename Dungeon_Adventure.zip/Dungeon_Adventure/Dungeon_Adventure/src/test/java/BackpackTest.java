import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

// Update the import below to match your actual package structure, for example:
import Dungeon_Adventure.Dungeon_Adventure.backpack.Package;
import Dungeon_Adventure.Dungeon_Adventure.backpack.*;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Classe di test per la struttura dati Backpack.
 * Verifica il corretto funzionamento dell'aggiunta, rimozione e visualizzazione degli oggetti nello zaino.
 * Utilizza JUnit 5 per i test unitari.
 */
// Testo una struttura dati complessa

public class BackpackTest {

    private Backpack<BackpackItem> backpack;

    @BeforeEach
    public void setup() {
        backpack = new Backpack<>();
    }

    // Test per verificare se l'inserimento di un oggetto funziona correttamente
    
    @Test
    public void testAddItem() {
        Item pozione = new Item("Pozione");
        backpack.addItem(pozione);

        assertFalse(backpack.isEmpty(), "Lo zaino non dovrebbe essere vuoto");
    }

    // Test per verificare se la rimozione di un oggetto funziona correttamente

    @Test
    public void testRemoveItem() {
        Item mappa = new Item("Mappa");
        backpack.addItem(mappa);
        backpack.removeItem(mappa);

        assertTrue(backpack.isEmpty(), "Lo zaino dovrebbe essere vuoto dopo la rimozione");
    }

    // Test per verificare se la visualizzazione annidata non causa crash

    @Test
    public void testNestedPackageDisplayDoesNotThrow() {
        Package pack = new Package("Pacco");
        pack.add(new Item("Chiave"));
        backpack.addItem(pack);

        assertDoesNotThrow(() -> backpack.displayContents());
    }
}
