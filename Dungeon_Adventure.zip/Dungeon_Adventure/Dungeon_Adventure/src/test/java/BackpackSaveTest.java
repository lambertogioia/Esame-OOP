// Update these imports to match your actual package structure.
// For example, if your package is 'dungeon_adventure.backpack' and 'dungeon_adventure.characters', use:

import Dungeon_Adventure.Dungeon_Adventure.characters.Player;

/**
 * Classe di test per verificare il salvataggio dello zaino del giocatore su file.
 * Crea un giocatore, aggiunge oggetti al suo zaino e salva il contenuto su un file.
 */

public class BackpackSaveTest {
    public static void main(String[] args) {
        //  Creo un player fittizio
        Player player = new Player("TestHero", 100, 10, 5);

        //  Aggiungo oggetti allo zaino
        player.addToBackpack("Pozione");
        player.addToBackpack("Spada");
        player.addToBackpack("Mappa");

        //  Salvo su file
        player.saveBackpackToFile("test_backpack.txt");

        System.out.println("Test completato. Controlla il file 'test_backpack.txt'");
    }
}
